#4. Write a shell script to find the file or directory with the maximum size in the current directory.

ls -S | head -n 1

